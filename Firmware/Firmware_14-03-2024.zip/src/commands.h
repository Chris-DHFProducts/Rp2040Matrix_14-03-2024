#ifndef __COMMANDS_H__
#define __COMMANDS_H__

#include "hub75.h"

bool Is_First_Run();
bool Command_Config_Read();

#endif // __COMMANDS_H__