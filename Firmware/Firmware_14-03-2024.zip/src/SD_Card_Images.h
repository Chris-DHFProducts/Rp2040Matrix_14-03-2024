#ifndef __MY_SD_CARD__
#define __MY_SD_CARD__


int Read_Image(char *filename, uint16_t Image_Pixel_Width, uint16_t Image_Pixel_Height, uint8_t *Screen_Buffer);

#endif // __MY_SD_CARD__