
#ifndef __MAIN__H_
#define __MAIN__H_

bool Has_Core_One_Been_Stated();
void core1_entry();

#endif // __MAIN__H_